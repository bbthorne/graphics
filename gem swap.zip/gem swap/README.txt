Ben Thorne
Computer Graphics Homework 1: 2D Game

Completed:
Stellar
Gyro
Turn-the-tables
Quake
Lovely
Bomb
Swap
Sticky
Dramatic Exit
Skyfall
Legal
Pulsate

I spent quite a bit of time on three-in-a-line, but it is not up to standard.
I left the code commented-out, in case you'd like to look at it!
