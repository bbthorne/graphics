Ben Thorne
Graphics Homework 2: 3D Homework
8/11/17

Here is the list of completed features:
Avatar
    Move in direction the heli is pointing: "I"
    Rotate: "J"
    Move Up: "K"
    Move Down: "L"
The Matrix Revolutions
Ground Zero
Sunshine
Highlander
Keep Watching
Dead Solid Perfect (Marble)
Spotlight
Shining
Tracking
Pitch Black
