Ben Thorne
Graphics Homework 3: Ray Tracing
12/3/17

Here is the list of completed features:

Environment
Pawns
Kings
Chessboard
Ebony and Ivory (Pawn, Rook, and Queen)
Sun
Wood
Normal mapping (King)
Queen
Rook
Animation
